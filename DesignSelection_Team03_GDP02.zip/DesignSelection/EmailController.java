package com.example.registrationlogindemo.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.registrationlogindemo.service.EmailService;
import com.example.registrationlogindemo.service.OtpService;
import com.example.registrationlogindemo.repository.OTPRepository;
import com.example.registrationlogindemo.repository.UserRepository;
import com.example.registrationlogindemo.dto.OtpDto;
import com.example.registrationlogindemo.entity.*;
// Annotation
@Controller
// Class
public class EmailController {
	@Autowired private EmailService emailService;
    private UserRepository userRepository;
	private PasswordEncoder passwordEncoder;

    public EmailController(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
		this.passwordEncoder= passwordEncoder;
    }
	// Sending a simple Email
	@PostMapping("/forget-password/proceed")
	public String resetPassword(@RequestParam("email") String email){
			User user = userRepository.findByEmail(email);
			if(user != null){
				Email details = new Email();
				Random rand = new Random();
				String new_pass = rand.nextInt(100000000)+"";
				details.setMsgBody("Your new password is : "+new_pass);
				details.setRecipient(email);
				details.setSubject("Reset your account password? - Design Select");
				Boolean status = emailService.sendSimpleMail(details);
				if(status){
					user.setPassword(passwordEncoder.encode(new_pass));
					userRepository.save(user);
					return "redirect:/login?new_pass"; //otp_check
				}
				else
					return "redirect:/forget_password?failed";
			}
			else	return "redirect:/forget-password?failed";
		}

	@PostMapping("/check-otp")
	public String checkOtp(@RequestParam("email") String email){
			User user = userRepository.findByEmail(email);
			if(user != null){
				Email details = new Email();
				String otp = "4455";
				details.setMsgBody("Your OTP is : "+otp);
				details.setRecipient(email);
				details.setSubject("Reset your account password? - Design Select");
				Boolean status = emailService.sendSimpleMail(details);
				if(status)
					return "redirect:/forget_password?otp"; //otp_check
				else 
					return "redirect:/forget_password?failed";
			}
			else	return "redirect:/forget-password?failed";
		}
	}
