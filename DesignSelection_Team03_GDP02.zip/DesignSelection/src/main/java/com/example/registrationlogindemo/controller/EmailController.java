package com.example.registrationlogindemo.controller;

import java.util.Random;
import java.util.UUID;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import com.example.registrationlogindemo.service.EmailService;
import com.example.registrationlogindemo.service.UserService;

import jakarta.servlet.http.HttpServletRequest;

import com.example.registrationlogindemo.repository.UserRepository;
import com.example.registrationlogindemo.entity.*;

// Annotation
@Controller
// Class
public class EmailController {
	@Autowired private EmailService emailService;
    private UserRepository userRepository;
	private UserService userService;

    public EmailController(UserRepository userRepository, UserService userService) {
        this.userRepository = userRepository;
        this.userService = userService;
    }
	// Sending a simple Email
	@PostMapping("/forget-password/proceed")
	public String resetPassword( HttpServletRequest request, 
	@RequestParam("email") String email){
			User user = userRepository.findByEmail(email);
			if(user != null){
				Email details = new Email();
				// Random rand = new Random();
				// String new_pass = rand.nextInt(100000000)+"";
				String token = UUID.randomUUID().toString();
				
				String url =  "http://"+request.getServerName() + ":" +request.getServerPort()+ "/reset-password?token=" + token;
				String message = "Reset your account password? - Design Select";
				details.setMsgBody("Your password reset link is : "+url);
				details.setRecipient(email);
				details.setSubject(message);
				Boolean status = emailService.sendSimpleMail(details);
				if(status){
					userService.updateResetPasswordToken(token, email);
					return "redirect:/login?reset_pass";
				}
				else
					return "redirect:/forget-password?failed";
			}
			else return "redirect:/forget-password?failed";
		}

    @PostMapping("/reset-password/reset")
    public String processResetPassword(HttpServletRequest request,
    @RequestParam("token") String token,
	@RequestParam("password") String password) {
        User user = userRepository.findByResetPasswordToken(token);
		if (user == null) {
            return "redirect:/login?invalid_token";
        } else {
            userService.updatePassword(user, password);
			return "redirect:/login?reset_success";
        }  
    }

}

