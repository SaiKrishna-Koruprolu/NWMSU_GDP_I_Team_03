package com.designselection.designselect;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DesignselectApplication {
	public static void main(String[] args) {
		SpringApplication.run(DesignselectApplication.class, args);
	}
}
