package com.designselection.designselect;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

@Controller
public class DesignselectController {
    @RequestMapping(value="/", method = RequestMethod.GET)
    public String dashboard(ModelMap model){
        model.addAttribute("activeHome", "active");
        return "home";
    }
    @RequestMapping("/login")
    public String login(){
        return "login";
    }
    @RequestMapping("/register")
    public String register(){
        return "register";
    }
    @RequestMapping("/forget-password")
    public String forgetPass(){
        return "forget_password";
    }
    @RequestMapping("/collections/new-arrivals")
    public String newArrivals(ModelMap model)
    {
        model.addAttribute("activeNewArrive", "active");
        return "new_arrivals";
    }
    @RequestMapping("/customize")
    public String customize(ModelMap model)
    {
        model.addAttribute("activeCustomize", "active");
        return "customize";
    }
}
