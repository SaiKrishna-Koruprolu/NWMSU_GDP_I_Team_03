package com.designselection.designselect;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DesignselectApplicationTests {

	@Test
	void contextLoads() {
	}

}
