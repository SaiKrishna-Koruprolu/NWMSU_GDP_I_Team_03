package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.entity.Product;
import java.util.List;
import java.util.Optional;

public interface ProductService {
    
    Optional<Product> findById(Long id);
    List<ProductDto> findAllProducts();
    List<ProductDto> findProductsByCategory(String category);
    List<ProductDto> findProductsByName(String name);
}
