package com.example.registrationlogindemo.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class ConversationDto
{
    private Long id;
    @NotEmpty
    private Long userid;
    @NotEmpty
    private String uname;
    @NotEmpty
    private String msg;
    @NotEmpty
    private String msgdate;
    @NotEmpty
    private int status;
}