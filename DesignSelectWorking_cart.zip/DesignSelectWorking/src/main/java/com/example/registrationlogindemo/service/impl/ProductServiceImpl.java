package com.example.registrationlogindemo.service.impl;

import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.dto.UserDto;
import com.example.registrationlogindemo.entity.Product;
import com.example.registrationlogindemo.entity.User;
import com.example.registrationlogindemo.repository.ProductRepository;
import com.example.registrationlogindemo.service.ProductService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ProductServiceImpl implements ProductService {
    private ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public void saveProduct(ProductDto productDto) {
        Product product = new Product();
        product.setName(productDto.getName());
        product.setPrice(productDto.getPrice());
        product.setRating(productDto.getRating());
        product.setId(productDto.getId());
        product.setImage(productDto.getImage());
        product.setCategory(productDto.getCategory());
        productRepository.save(product);
    }
    
    @Override
    public List<ProductDto> findAllProducts() {
        List<Product> products = productRepository.findAll();
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }

    private ProductDto convertEntityToDto(Product product){
        ProductDto productDto = new ProductDto();
        productDto.setId(product.getId());
        productDto.setName(product.getName());
        productDto.setPrice(product.getPrice());
        productDto.setImage(product.getImage());
        productDto.setCategory(product.getCategory());
        productDto.setRating(product.getRating());
        productDto.setAvail_qty(product.getAvail_qty());
        return productDto;
    }

    @Override
    public Optional<Product> findById(Long id) {
        return productRepository.findById(id);
    }
    
    @Override
    public List<ProductDto> findProductsByCategory(String categorgy) {
         List<Product> products = productRepository.findProductsByCategory(categorgy);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }
}
