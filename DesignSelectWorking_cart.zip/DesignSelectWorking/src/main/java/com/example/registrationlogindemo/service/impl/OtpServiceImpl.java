package com.example.registrationlogindemo.service.impl;

import com.example.registrationlogindemo.dto.OtpDto;
import com.example.registrationlogindemo.entity.Otp;

import com.example.registrationlogindemo.repository.OTPRepository;
import com.example.registrationlogindemo.repository.RoleRepository;
import com.example.registrationlogindemo.repository.UserRepository;
import com.example.registrationlogindemo.service.OtpService;
import com.example.registrationlogindemo.service.UserService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

@Service
public class OtpServiceImpl implements OtpService {
    private OTPRepository otpRepository;
    public OtpServiceImpl(OTPRepository otpRepository) {
        this.otpRepository=otpRepository;
    }
    @Override
    public void saveOtp(OtpDto otpDto) {
        Otp otp = new Otp();
        otp.setEmail(otpDto.getEmail());
        otp.setOtp(otpDto.getOtp());
        otpRepository.save(otp);
    }

    @Override
    public Otp findByEmail(String email) {
        return otpRepository.findByEmail(email);
    }
}
