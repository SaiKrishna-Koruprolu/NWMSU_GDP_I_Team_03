package com.example.registrationlogindemo.service.impl;

import com.example.registrationlogindemo.dto.CustomizeDto;
import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.dto.UserDto;
import com.example.registrationlogindemo.entity.Customize;
import com.example.registrationlogindemo.entity.Product;
import com.example.registrationlogindemo.entity.User;
import com.example.registrationlogindemo.repository.CustomizeRepository;
import com.example.registrationlogindemo.repository.ProductRepository;
import com.example.registrationlogindemo.service.CustomizeService;
import com.example.registrationlogindemo.service.ProductService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CustomizeServiceImpl implements CustomizeService {
    private CustomizeRepository customizeRepository;

    public CustomizeServiceImpl(CustomizeRepository customizeRepository) {
        this.customizeRepository = customizeRepository;
    }

    public void saveCustomize(CustomizeDto customizeDto) {
        Customize product = new Customize();
        product.setTitle(customizeDto.getTitle());
        product.setDescription(customizeDto.getDescription());
        product.setImage(customizeDto.getImage());
        product.setMin_price(customizeDto.getMin_price());
        product.setMax_price(customizeDto.getMax_price());
        product.setFinal_price(customizeDto.getFinal_price());
        product.setQty(customizeDto.getQty());
        product.setSize(customizeDto.getSize());
        product.setUid(customizeDto.getUid());
        product.setStatus(customizeDto.getStatus());
        customizeRepository.save(product);
    }
    
    private CustomizeDto convertEntityToDto(Customize product){
        CustomizeDto productDto = new CustomizeDto();
        productDto.setId(product.getId());
        productDto.setTitle(product.getTitle());
        productDto.setDescription(product.getDescription());
        productDto.setImage(product.getImage());
        productDto.setMin_price(product.getMin_price());
        productDto.setMax_price(product.getMax_price());
        productDto.setFinal_price(product.getFinal_price());
        productDto.setQty(product.getQty());
        productDto.setSize(product.getSize());
        productDto.setUid(product.getUid());
        productDto.setStatus(product.getStatus());
        return productDto;
    }

    @Override
    public Optional<Customize> findById(Long id) {
        return customizeRepository.findById(id);
    }

    @Override
    public List<CustomizeDto> findProductsByUid(Long uid) {
         List<Customize> products = customizeRepository.findProductsByUid(uid);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }

    @Override
    public List<CustomizeDto> findProductsByTitle(String title) {
        List<Customize> products = customizeRepository.findProductsByTitle(title);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }

    @Override
    public List<CustomizeDto> findProductsByStatus(int status) {
        List<Customize> products = customizeRepository.findProductsByStatus(status);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }

    public void updateCustomizeDetails(Customize customize) {
        customizeRepository.save(customize);
    }
}
