package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.dto.CartDto;
import com.example.registrationlogindemo.entity.Cart;
import java.util.List;
import java.util.Optional;

public interface CartService {
    void saveCart(CartDto CartDto);
    
    Optional<Cart> findById(Long id);
    List<CartDto> findProductsByUidANDStatus(Long uid, int status);
    void updateCartDetails(Cart cart);
    void deleteCartDetails(Long id);
}
