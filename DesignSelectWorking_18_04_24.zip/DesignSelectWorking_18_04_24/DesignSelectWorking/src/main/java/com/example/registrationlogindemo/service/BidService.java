package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.dto.BidDto;
import com.example.registrationlogindemo.entity.Bid;
import com.example.registrationlogindemo.entity.User;

import java.util.List;
import java.util.Optional;

public interface BidService {
    void saveBid(BidDto bidDto);
    
    Optional<Bid> findById(Long id);
    List<BidDto> findProductsByUid(Long uid);
    List<BidDto> findProductsByCstid(Long cstid);
    List<BidDto> findProductsByStatus(int status);

}