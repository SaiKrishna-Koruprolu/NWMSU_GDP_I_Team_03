package com.example.registrationlogindemo.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class BidDto
{
    private Long id;
    private Long uid;
    
    private Long cstid;
    
    private Double price;
    
    private Long timestamp;

    private int status;
}