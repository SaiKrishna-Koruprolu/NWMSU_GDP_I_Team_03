package com.example.registrationlogindemo.controller;

import com.example.registrationlogindemo.dto.BidDto;
import com.example.registrationlogindemo.dto.CartDto;
import com.example.registrationlogindemo.dto.ChatDto;
import com.example.registrationlogindemo.dto.ConversationDto;
import com.example.registrationlogindemo.dto.CustomizeDto;
import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.dto.UserDto;
import com.example.registrationlogindemo.entity.User;
import com.example.registrationlogindemo.service.UserService;
import com.example.registrationlogindemo.service.BidService;
import com.example.registrationlogindemo.service.CartService;
import com.example.registrationlogindemo.service.ChatService;
import com.example.registrationlogindemo.service.ConversationService;
import com.example.registrationlogindemo.service.CustomizeService;
import com.example.registrationlogindemo.service.ProductService;

import jakarta.validation.Valid;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.registrationlogindemo.entity.Bid;
import com.example.registrationlogindemo.entity.Cart;
import com.example.registrationlogindemo.entity.Chat;
import com.example.registrationlogindemo.entity.Conversation;
import com.example.registrationlogindemo.entity.Customize;
import com.example.registrationlogindemo.entity.Email;
import com.example.registrationlogindemo.entity.Product;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;

@Controller
public class AuthController {
    private UserService userService;
    private ProductService productService;
    private CustomizeService customizeService;
    private CartService cartService;
    private ChatService chatService;
    private BidService bidService;
    private ConversationService conversationService;
    private String app_name = "Design Selection";
    
    public AuthController(UserService userService, 
                ProductService productService,
                CartService cartService,
                ChatService chatService,
                CustomizeService customizeService,
                BidService bidService,
                ConversationService conversationService) {
        this.userService = userService;
        this.productService = productService;
        this.cartService = cartService;
        this.chatService = chatService;
        this.customizeService = customizeService;
        this.bidService = bidService;
        this.conversationService = conversationService;
    }

    @GetMapping("/")
    public String index(){
        return "login";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @GetMapping("/forget-password")
    public String forget_pass(Email email) {
        return "forget_pass";
    }

    @GetMapping("/reset-password")
    public String showChangePasswordPage(Locale locale, Model model, 
    @RequestParam("token") String token) {
        User user = userService.getByResetPasswordToken(token);
        model.addAttribute("token", token);

        if (user == null) {
            model.addAttribute("message", "Invalid Token");
            return "redirect:/login?invalid_token";
        }
        return "reset_pass";
    }

    // handler method to handle user registration request
    @GetMapping("register")
    public String showRegistrationForm(Model model){
        UserDto user = new UserDto();
        model.addAttribute("user", user);
        return "register";
    }

    // handler method to handle register user form submit request
    @PostMapping("/register/save")
    public String registration(@Valid @ModelAttribute("user") UserDto user,
                               BindingResult result,
                               Model model){
        
        User existing = userService.findByEmail(user.getEmail());
        if (existing != null) {
            result.rejectValue("email", null, "There is already an account registered with that email");
        }
        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "register";
        }
        userService.saveUser(user);
        return "redirect:/login?success";
    }
    
    // @GetMapping("/users")
    // public String listRegisteredUsers(Model model){
    //     List<UserDto> users = userService.findAllUsers();
    //     model.addAttribute("users", users);
    //     return "users";
    // }
    
    @GetMapping("/home")
    public String getHome(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Home" );
            model.addAttribute("activeHome", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "home";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/new-arrivals")
    public String getNewarrival(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("new-arrival");
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "New-arrivals" );
            model.addAttribute("activeNewArrival", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);
            return "new-arrival";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/search")
    public String getNewarrivalSearch(@RequestParam String search, ModelMap model){
        List<ProductDto> products = productService.findProductsByNameContainingIgnoreCase(search);
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Search" );
            model.addAttribute("activeNewArrival", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);
            return "new-arrival";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/collections/women")
    public String getWomenCollections(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("women");
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Women" );    
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("activeWomen", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "women";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/men")
    public String getMensCollection(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("men");

        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Men");    
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("activeMen", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "men";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/girls")
    public String getGirlsCollection(ModelMap model){  
        List<ProductDto> products = productService.findProductsByCategory("girls");

        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Girls" );  
            model.addAttribute("activeGirls", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "girls";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/boys")
    public String getBoysCollection(ModelMap model){
        User user = this.getUserById(model);
        List<ProductDto> products = productService.findProductsByCategory("boys");

        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Boys" );  
            model.addAttribute("activeBoys", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "boys";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/kids")
    public String getKidsCollection(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("kids");

        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Kids" );  
            model.addAttribute("activeKids", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "kids";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/sale")
    public String getSale(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("sale");

        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Sale" );  
            model.addAttribute("activeSale", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "sale";
        }else
            return "redirect:/login?error";
    }
    
    @SuppressWarnings("null")
    @GetMapping("/add-to-cart")
    public String getMethodName(@RequestParam Long productId, 
                            CartDto cart, ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            Optional<Product> product = productService.findById(productId);
            // add to cart table with user-id & product details
            if(product == null)
                return "redirect:/login?error";
            
            cart.setName(product.get().getName());
            cart.setCategory(product.get().getCategory());
            cart.setImage(product.get().getImage());
            cart.setPrice(product.get().getPrice());
            cart.setUid(user.getId());
            cart.setQty(1);
            
            cartService.saveCart(cart);
            return "redirect:/cart";
        }
        return "redirect:/login?error";
    }
    
  
    @SuppressWarnings("null")
    @GetMapping("/remove-cart-item")
    public String removeCartItem(@RequestParam(required = true) Long id, ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            cartService.deleteCartDetails(id);
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            
            model.addAttribute("page_title", "Cart" );
            model.addAttribute("activeCart", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("carts", carts);
            return "redirect:/cart";
        }else
            return "redirect:/login?error";
    }
    @GetMapping("/cart")
    public String getCart(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            
            model.addAttribute("page_title", "Cart" );
            model.addAttribute("activeCart", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("carts", carts);
            return "cart";
        }else
            return "redirect:/login?error";
    }

    // @GetMapping("/chats")
    // public String getConversations(ModelMap model) {
    //     User user = this.getUserById(model);
    //     if(user.getId() != null){
    //         List<ConversationDto> chats = conversationService.findConversationByUserid(user.getId());
    //         model.addAttribute("page_title", "Chat");
    //         model.addAttribute("user_id", user.getId());
    //         model.addAttribute("role", user.getRole());
    //         model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
    //         model.addAttribute("conversations", chats);
    //         Chat chat = new Chat();
    //         model.addAttribute("chats", chat);
    //         return "chat";
    //     }else
    //         return "redirect:/login?error";
    // }

    @GetMapping("/chats")
    public String getConversations(ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<UserDto> vendors = userService.findByRole(3);
            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("conversations", vendors);
            model.addAttribute("conversationid", 0);
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            Chat chat = new Chat();
            model.addAttribute("chats", chat);
            return "chat";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/vendor-chats")
    public String getVendorConversations(ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<UserDto> vendors = userService.findByRole(2);
            
            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("conversations", vendors);
            model.addAttribute("conversationid", 0);

            Chat chat = new Chat();
            model.addAttribute("chats", chat);
            return "chat";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/vendor-chat")
    public String getVendorChat(@RequestParam(required = true) int conversationid, ModelMap model) {
        User user = this.getUserById(model);

        if(user.getId() != null){
            List<ChatDto> chats = chatService.findConversationByConversationid((user.getId()).intValue());
            // List<ConversationDto> chat_conversations = conversationService.findConversationByUserid(user.getId());
            List<UserDto> chat_conversations = userService.findByRole(2);

            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("chats", chats);
            model.addAttribute("conversationid", conversationid);
            model.addAttribute("conversations", chat_conversations);
            return "chat";
        }else
            return "redirect:/login?error";
    }
   
    @GetMapping("/chat")
    public String getChat(@RequestParam(required = true) int conversationid, ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<ChatDto> chats = chatService.findConversationByConversationid(conversationid);
            // List<ConversationDto> chat_conversations = conversationService.findConversationByUserid(user.getId());
            List<UserDto> chat_conversations = userService.findByRole(3);
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("chats", chats);
            model.addAttribute("conversationid", conversationid);
            model.addAttribute("conversations", chat_conversations);
            return "chat";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/chat-send")
    public String sendMsg(ChatDto chatDto,  ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            // add to cart table with user-id & product details
            // if(msg == null)
            //     return "redirect:/chat";
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            
            chatDto.setMsgdate(dtf.format(now));
            chatService.saveChat(chatDto);
            ConversationDto conversation = new ConversationDto();
            conversation.setMsg(chatDto.getMsg());
            conversation.setMsgdate(chatDto.getMsgdate());
            conversation.setUserid(chatDto.getSenderid());
            conversation.setStatus(0);
            try{
                conversationService.saveConversation(conversation);
            }catch(Exception ex){
                ex.printStackTrace();
            }
            if(user.getRole() == 2)
                return "redirect:/chat?conversationid="+chatDto.getConversationid();
            else if(user.getRole() == 3)
                return "redirect:/vendor-chat?conversationid="+chatDto.getConversationid();
        }
        return "redirect:/login?error";
    }
    
    @GetMapping("/customize")
    public String getCustomize(ModelMap model){
        // List<ProductDto> products = productService.findProductsByType("women");
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Customize" );
            model.addAttribute("activeCustomize", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            // model.addAttribute("products", products);
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            return "customize";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/profile-details")
    public String profile_details(ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "User Profile");
            model.addAttribute("activeProfile", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("firstname", user.getFirstName());
            model.addAttribute("lastname", user.getLastName());
            model.addAttribute("email", user.getEmail());
            return "customer_profile";
        }else
            return "redirect:/login?error";
    }

    @PostMapping("/update-user-profile")
    public String update_user_profile(@Valid @ModelAttribute("user") UserDto userDto,  BindingResult result,  Model model){
            // User existing = this.getUserById(modelMap);
        User user = userService.findByEmail(userDto.getEmail());
        userService.updateUserDetails(user, userDto.getFirstName(), userDto.getLastName());
        return "redirect:/profile-details?success";
    }

    @PostMapping("/payment-page")
    public String paymentPage(ModelMap model,
    @RequestParam Map<String, String> requestParams){
        String tot_cart = requestParams.get("cart_total");
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Payment" );
            model.addAttribute("activeHome", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("tot_cart", tot_cart);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
          
            return "payment";
        }else
            return "redirect:/login?error";
    }
    
    @PostMapping("/proceed-pay")
    public String proceed_pay(ModelMap model,
    @RequestParam Map<String, String> requestParams){
        String tot_cart = requestParams.get("cart_total");
        // System.out.println("tot_cart:--->"+tot_cart);

        User user = this.getUserById(model);
        if(user.getId() != null){
            // move cart items to history table
            List<CartDto> cart_list = cartService.findProductsByUidANDStatus(user.getId(), 0);
            for (CartDto cartDto : cart_list) {
                Cart cart = new Cart();

                cart.setId(cartDto.getId());
                cart.setName(cartDto.getName());
                cart.setImage(cartDto.getImage());
                cart.setPrice(cartDto.getPrice());
                cart.setQty(cartDto.getQty());
                cart.setUid(cartDto.getUid());
                cart.setStatus(1);
                cart.setCategory(cartDto.getCategory());
                
                cartService.updateCartDetails(cart);
            }
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Payment success" );
            model.addAttribute("activeHome", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("tot_cart", tot_cart);
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "payment_success";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/bids/open-bids")
    public String openBids(ModelMap model){
        List<CustomizeDto> products = customizeService.findProductsByStatus(0);

        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Bids" );
            model.addAttribute("activeBids", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", products);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            
            return "open_bids";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/bids/open-bids/action")
    public String open_bids_action(
        @RequestParam(value = "bid_price", required = true) Double bid_price,
        @RequestParam(value = "id", required = true) Long id,
        ModelMap model) {
        User user = this.getUserById(model);

        if(user.getId() != null){
            Optional <Customize>  customize = customizeService.findById(id);

            // check cust_id and uid in bids table
            List<BidDto>  bids = bidService.findProductsByCstid(id);

            for (BidDto bidDto : bids) {
                if(bidDto.getUid() == user.getId()){
                    return "redirect:/bids/open-bids?error";
                }
            }
            
            Customize customize2 = new Customize();
            if(customize == null)
                return "redirect:/bids/open-bids?error";
            
            // update customize status
            
            customize2.setId(customize.get().getId());
            customize2.setTitle(customize.get().getTitle());
            customize2.setDescription(customize.get().getDescription());
            customize2.setImage(customize.get().getImage());
            customize2.setQty(customize.get().getQty());
            customize2.setMax_price(customize.get().getMax_price());
            customize2.setFinal_price(customize.get().getFinal_price());
            customize2.setMin_price(customize.get().getMin_price());
            customize2.setSize(customize.get().getSize());
            customize2.setUid(customize.get().getUid());
            customize2.setStatus(0);

            customizeService.updateCustomizeDetails(customize2);

            // insert into bids 
            BidDto bidDto = new BidDto();
            bidDto.setCstid(customize.get().getId());
            bidDto.setPrice(bid_price);
            bidDto.setTimestamp(System.currentTimeMillis());
            bidDto.setUid(user.getId());
            bidService.saveBid(bidDto);
            
            return "redirect:/bids/open-bids?success";
        }else
            return "redirect:/login?error";
    }
    
    List<CustomizeDto> customizeDtos = new ArrayList<>();
    @GetMapping("/bids/my-bids")
    public String myBids(ModelMap model){
        
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<BidDto> products = bidService.findProductsByUid(user.getId());
            customizeDtos.clear();
            for (BidDto product : products) {
                Optional<Customize> customize = customizeService.findById(product.getCstid());
                CustomizeDto custDto = new CustomizeDto();
                custDto.setImage(customize.get().getImage());
                custDto.setMin_price(customize.get().getMin_price());
                custDto.setMax_price(customize.get().getMax_price());
                custDto.setTitle(customize.get().getTitle());
                custDto.setStatus(product.getStatus());
                custDto.setQty(customize.get().getQty());
                custDto.setSize(customize.get().getSize());
                custDto.setDescription(product.getPrice()+""); //temp using the column
                customizeDtos.add(custDto);
            }

            model.addAttribute("page_title", "Bids" );
            model.addAttribute("activeBids", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", customizeDtos);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            
            return "my_bids";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/bids/my-bid-close")
    public String myBidOpen(ModelMap model,
    @RequestParam(value = "id", required = true) Long id){
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<BidDto> bids = bidService.findProductsByCstid(id);
            Optional<Customize> customize_item = customizeService.findById(id);

            Double min_bid = 0.00;
            Long bid_id = null;
            for (BidDto bid : bids) {
                // System.out.println("min_bid:-"+min_bid);

                if(min_bid < 0.01){
                    min_bid = bid.getPrice();
                    bid_id = bid.getId();
                }
                else if(bid.getPrice() < min_bid)
                {
                    min_bid = bid.getPrice();
                    bid_id = bid.getId();
                }
                
                // System.out.println("min_bid:-"+bid.getPrice());
                // System.out.println("bid_id:-"+bid.getId());
            }

            Customize customize = new Customize();
            customize.setId(customize_item.get().getId());
            customize.setUid(customize_item.get().getUid());
            customize.setImage(customize_item.get().getImage());
            customize.setMin_price(customize_item.get().getMin_price());
            customize.setMax_price(customize_item.get().getMax_price());
            customize.setTitle(customize_item.get().getTitle());
            customize.setQty(customize_item.get().getQty());
            customize.setSize(customize_item.get().getSize());
            customize.setDescription(customize_item.get().getDescription());
            customize.setFinal_price(min_bid);
            customize.setStatus(1);
            customizeService.updateCustomizeDetails(customize);

            // change bid status to closed

            for (BidDto bid : bids) {
                Optional<Bid> old_bid=bidService.findById(bid.getId());
                BidDto new_bid= new BidDto();
                new_bid.setCstid(old_bid.get().getCstid());
                new_bid.setPrice(old_bid.get().getPrice());
                new_bid.setTimestamp(old_bid.get().getTimestamp());
                new_bid.setId(old_bid.get().getId());
                new_bid.setUid(old_bid.get().getUid());

                if(bid_id != null && bid.getId() == bid_id){
                    new_bid.setStatus(1);
                }else{
                    new_bid.setStatus(2);
                }
                
                bidService.saveBid(new_bid);
            }
            // assign bid to vendor
           
            return "redirect:/customize-history?success";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/customize-history")
    public String customizeHistory(ModelMap model){
        
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CustomizeDto> products = customizeService.findProductsByUid(user.getId());
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Bids" );
            model.addAttribute("activeBids", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", products);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            
            return "my_customizes";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/orders-history")
    public String ordersHistory(ModelMap model){   
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> products = cartService.findProductsByUidANDStatus(user.getId(), 1);
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "Orders History");
            model.addAttribute("activeProfile", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", products);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "my_orders_history";
        }else
            return "redirect:/login?error";
    }
    
    public User getUserById(ModelMap model){
          // List<ProductDto> products = ProductService.findAllProducts();
          SecurityContext context=SecurityContextHolder.getContext();
          Authentication authentication=context.getAuthentication();
          User user = new User();
          try{
              String email=((UserDetails)authentication.getPrincipal()).getUsername();
              user = (User)userService.findByEmail(email);
          }catch(Exception ex){
          }
        return user;
    }

    @GetMapping("/products/my-products")
    public String my_products(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<ProductDto> products = productService.findProductsByUid(user.getId());
            List<CartDto> carts = cartService.findProductsByUidANDStatus(user.getId(), 0);
            model.addAttribute("cart_count", carts.size());
            model.addAttribute("page_title", "My Products");
            model.addAttribute("activeProduct", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", products);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "my_products";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/products/add-product")
    public String add_product(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Product" );
            model.addAttribute("activeProduct", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            
            return "add_product";
        }else
            return "redirect:/login?error";
    }
    
    // edit-product
    @GetMapping("/products/edit-product")
    public String edit_product(ModelMap model,
                @RequestParam(required = true) long id){
        User user = this.getUserById(model);
        if(user.getId() != null){
            Optional<Product> product = productService.findById(id);

            model.addAttribute("page_title", "Product" );
            model.addAttribute("activeProduct", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("product", product.get());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "edit_product";
        }else
            return "redirect:/login?error";
    }
    

    @PostMapping("/products/update-product")
    public String update_vendor_product(@Valid @ModelAttribute("product") ProductDto productDto,  BindingResult result,  Model model){
            // User existing = this.getUserById(modelMap);
        Optional<Product> productOpt = productService.findById(productDto.getId());
        Product product = new Product();
        product.setId(productOpt.get().getId());
        product.setName(productDto.getName());
        product.setCategory(productDto.getCategory());
        product.setAvail_qty(productDto.getAvail_qty());
        product.setRating(productDto.getRating());
        product.setPrice(productDto.getPrice());
        product.setUid(productDto.getUid());
        product.setImage(productOpt.get().getImage());

        productService.updateProductDetails(product);
        return "redirect:/my-products?success";
    }

    public static String SYS_DIRECTORY = System.getProperty("user.dir");
    public static String UPLOAD_DIRECTORY = "/src/main/resources/static/img/product/";
    public static String FILE_DIRECTORY = "/img/product/";
    
    // handler method to handle register user form submit request
    @PostMapping("/products/add-product/save")
    public String saveProduct(@Valid @ModelAttribute("product") ProductDto product,
                            BindingResult result,
                            Model model,
                            @RequestParam("file_img") MultipartFile file)throws IOException{
                                
        StringBuilder fileNames = new StringBuilder();
        Path fileNameAndPath = Paths.get(SYS_DIRECTORY+UPLOAD_DIRECTORY, file.getOriginalFilename());
        fileNames.append(file.getOriginalFilename());
        
        try {
            Files.write(fileNameAndPath, file.getBytes());
        } catch (IOException e) {
            System.out.println("error file:--->"+e.getMessage());
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        product.setImage(FILE_DIRECTORY + file.getOriginalFilename());
        // model.addAttribute("msg", "Uploaded images: " + fileNames.toString());
        
        productService.saveProduct(product);
        return "redirect:/products/add-product?success";
    }


    @PostMapping("/products/upload-customize")
    public String uploadCustomize(@Valid @ModelAttribute("customize") CustomizeDto customizeDto,
                            BindingResult result,
                            Model model,
                            @RequestParam("file_img") MultipartFile file)throws IOException{
                                
        StringBuilder fileNames = new StringBuilder();
        Path fileNameAndPath = Paths.get(SYS_DIRECTORY+UPLOAD_DIRECTORY, file.getOriginalFilename());
        fileNames.append(file.getOriginalFilename());
        
        try {
            Files.write(fileNameAndPath, file.getBytes());
        } catch (IOException e) {
            System.out.println("error file:--->"+e.getMessage());
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "redirect:/customize?error";
        }
        
        customizeDto.setImage(FILE_DIRECTORY + file.getOriginalFilename());
        // model.addAttribute("msg", "Uploaded images: " + fileNames.toString());
        
        customizeService.saveCustomize(customizeDto);
        return "redirect:/customize?success";
    }
}
