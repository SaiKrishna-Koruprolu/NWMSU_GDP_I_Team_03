package com.example.registrationlogindemo.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class CustomizeDto
{
    private Long id;
    private Long uid;
    private String title;
    @NotEmpty
    private String description;
    
    private Double min_price;
    private Double max_price;
    private Double final_price;
    private int qty;
    @NotEmpty
    private String image;
    @NotEmpty
    private String size;
    private int status;
}