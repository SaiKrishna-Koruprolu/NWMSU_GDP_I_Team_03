package com.example.registrationlogindemo.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="bids")
public class Bid
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(nullable=false)
    private Long uid;
    
    @Column(nullable=false)
    private Long cstid;
    
    @Column(nullable=false)
    private Long timestamp;

    @Column(nullable=false)
    private Double price;

    private int status;
}