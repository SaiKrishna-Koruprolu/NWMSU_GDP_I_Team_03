package com.example.registrationlogindemo.service.impl;
import com.example.registrationlogindemo.dto.BidDto;
import com.example.registrationlogindemo.entity.Bid;
import com.example.registrationlogindemo.repository.BidRepository;
import com.example.registrationlogindemo.service.BidService;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BidServiceImpl implements BidService {
    private BidRepository bidRepository;

    public BidServiceImpl(BidRepository bidRepository) {
        this.bidRepository = bidRepository;
    }

    public void saveBid(BidDto bidDto) {
        Bid product = new Bid();
        product.setUid(bidDto.getUid());
        product.setId(bidDto.getId());
        product.setCstid(bidDto.getCstid());
        product.setTimestamp(bidDto.getTimestamp());
        product.setPrice(bidDto.getPrice());
        product.setStatus(bidDto.getStatus());
        bidRepository.save(product);
    }
    
    private BidDto convertEntityToDto(Bid product){
        BidDto productDto = new BidDto();
        productDto.setId(product.getId());
        productDto.setCstid(product.getCstid());
        productDto.setPrice(product.getPrice());
        productDto.setTimestamp(product.getTimestamp());
        productDto.setUid(product.getUid());
        productDto.setStatus(product.getStatus());
        return productDto;
    }

    @Override
    public Optional<Bid> findById(Long id) {
        return bidRepository.findById(id);
    }

    @Override
    public List<BidDto> findProductsByUid(Long uid) {
         List<Bid> products = bidRepository.findProductsByUid(uid);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }

    @Override
    public List<BidDto> findProductsByCstid(Long cstid) {
        List<Bid> products = bidRepository.findProductsByCstid(cstid);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }

    @Override
    public List<BidDto> findProductsByStatus(int status) {
        List<Bid> products = bidRepository.findProductsByStatus(status);
        return products.stream().map((product) -> convertEntityToDto(product))
                .collect(Collectors.toList());
    }
}
