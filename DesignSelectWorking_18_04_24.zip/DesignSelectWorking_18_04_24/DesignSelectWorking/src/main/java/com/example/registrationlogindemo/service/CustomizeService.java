package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.dto.CustomizeDto;
import com.example.registrationlogindemo.entity.Customize;
import com.example.registrationlogindemo.entity.User;

import java.util.List;
import java.util.Optional;

public interface CustomizeService {
    void saveCustomize(CustomizeDto CustomizeDto);
    
    Optional <Customize> findById(Long id);
    List<CustomizeDto> findProductsByUid(Long uid);
    List<CustomizeDto> findProductsByTitle(String title);
    List<CustomizeDto> findProductsByStatus(int status);
    void updateCustomizeDetails(Customize customize);

}