package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.entity.Product;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
    @SuppressWarnings("null")
    Optional<Product> findById(Long id);
    List<Product> findProductsByCategory(String category);
    List<Product> findProductsByNameContainingIgnoreCase(String name);
    List<Product> findProductsByUid(Long uid);
    List<Product> findProductsByPriceBetween(Double min_price, Double max_price);
}
