package com.example.registrationlogindemo.repository;


import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.registrationlogindemo.entity.Bid;

public interface BidRepository extends JpaRepository<Bid, Long> {
    @SuppressWarnings("null")
    Optional<Bid> findById(Long id);
    List<Bid> findProductsByUid(Long uid);
    List<Bid> findProductsByCstid(Long cstid);
    List<Bid> findProductsByStatus(int status);
}
