package com.example.registrationlogindemo.entity;

import java.sql.Date;
import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Entity
@Table(name="chat")
public class Chat
{
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(nullable=false)
    private Long receiverid;

    @Column(nullable=false)
    private int conversationid;
    
    @Column(nullable=false)
    private Long senderid;
    
    @Column(nullable=false)
    private String msg;
    
    @Column(nullable=false)
    private String msgdate;

    @Column(nullable=false)
    private int status;
}