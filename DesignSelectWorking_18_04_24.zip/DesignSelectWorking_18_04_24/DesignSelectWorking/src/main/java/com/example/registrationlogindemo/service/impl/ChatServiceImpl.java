package com.example.registrationlogindemo.service.impl;

import org.springframework.stereotype.Service;

import com.example.registrationlogindemo.dto.ChatDto;
import com.example.registrationlogindemo.entity.Chat;
import com.example.registrationlogindemo.repository.ChatRepository;
import com.example.registrationlogindemo.service.ChatService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ChatServiceImpl implements ChatService {
    private ChatRepository chatRepository;

    public ChatServiceImpl(ChatRepository chatRepository) {
        this.chatRepository = chatRepository;
    }
    
    @Override
    public void saveChat(ChatDto chatDto) {
        Chat chat = new Chat();
        chat.setId(chatDto.getId());
        chat.setMsg(chatDto.getMsg());
        chat.setSenderid(chatDto.getSenderid());
        chat.setReceiverid(chatDto.getReceiverid());
        chat.setConversationid(chatDto.getConversationid());
        chat.setStatus(chatDto.getStatus());
        chat.setMsgdate(chatDto.getMsgdate());
        chatRepository.save(chat);
    }

    @Override
    public Optional<Chat> findById(Long id) {
        Optional<Chat> chat = chatRepository.findById(id);
        return chat;
    }

    private ChatDto convertEntityToDto(Chat chat){
        ChatDto chatDto = new ChatDto();
        chatDto.setId(chat.getId());
        chatDto.setMsg(chat.getMsg());
        chatDto.setSenderid(chat.getSenderid());
        chatDto.setReceiverid(chat.getReceiverid());
        chatDto.setConversationid(chat.getConversationid());
        chatDto.setStatus(chat.getStatus());
        chatDto.setMsgdate(chat.getMsgdate());
        return chatDto;
    }
    
    @Override
    public List<ChatDto> findConversationByConversationid(int conversatioinid) {
        List<Chat> chats = chatRepository.findConversationByConversationid(conversatioinid);
        return chats.stream().map((chat) -> convertEntityToDto(chat))
                .collect(Collectors.toList());
    }

    @Override
    public List<ChatDto> findConversationBySenderid(Long senderid) {
        List<Chat> chats = chatRepository.findConversationBySenderid(senderid);
        return chats.stream().map((chat) -> convertEntityToDto(chat))
                .collect(Collectors.toList());
    }
    

    @Override
    public List<ChatDto> findConversationByReceiverid(Long receiverid) {
        List<Chat> chats = chatRepository.findConversationByReceiverid(receiverid);
        return chats.stream().map((chat) -> convertEntityToDto(chat))
                .collect(Collectors.toList());
    }
    
}
