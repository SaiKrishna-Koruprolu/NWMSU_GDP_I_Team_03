package com.example.registrationlogindemo.dto;

import jakarta.validation.constraints.NotEmpty;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor

public class CartDto
{
    private Long id;
    @NotEmpty
    private Long uid;
    @NotEmpty
    private String name;
    @NotEmpty
    private String category;
    @NotEmpty
    private Double price;
    @NotEmpty
    private int qty;
    @NotEmpty
    private String image;
    @NotEmpty
    private int status;
}