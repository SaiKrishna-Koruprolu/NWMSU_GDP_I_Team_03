package com.example.registrationlogindemo.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ProductDto
{
    private Long id;
    private Long uid;
    private String name;
    @NotEmpty
    private String category;
    private Double price;

    private int avail_qty;
    @NotEmpty
    private String image;
    private int rating;
}