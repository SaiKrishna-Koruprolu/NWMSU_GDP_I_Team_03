package com.example.registrationlogindemo.service.impl;

import com.example.registrationlogindemo.dto.CartDto;
import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.entity.Cart;
import com.example.registrationlogindemo.repository.CartRepository;
import com.example.registrationlogindemo.service.CartService;

import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class CartServiceImpl implements CartService {
    private CartRepository cartRepository;

    public CartServiceImpl(CartRepository cartRepository) {
        this.cartRepository = cartRepository;
    }
    
    @Override
    public void saveCart(CartDto cartDto) {
        Cart cart = new Cart();
        cart.setId(cartDto.getId());
        cart.setName(cartDto.getName());
        cart.setCategory(cartDto.getCategory());
        cart.setImage(cartDto.getImage());
        cart.setUid(cartDto.getUid());
        cart.setPrice(cartDto.getPrice());
        cart.setQty(cartDto.getQty());
        cartRepository.save(cart);
    }

    @Override
    public Optional<Cart> findById(Long id) {
        Optional<Cart> product = cartRepository.findById(id);
        return product;
    }
    
    @Override
    public List<CartDto> findProductsByUid(Long user_id) {
        List<Cart> products = cartRepository.findProductsByUid(user_id);
        return products.stream().map((cart) -> convertEntityToDto(cart))
                .collect(Collectors.toList());
    }

    private CartDto convertEntityToDto(Cart product){
        CartDto productDto = new CartDto();
        productDto.setId(product.getId());
        productDto.setName(product.getName());
        productDto.setPrice(product.getPrice());
        productDto.setImage(product.getImage());
        productDto.setUid(product.getUid());
        productDto.setCategory(product.getCategory());
        return productDto;
    }
}
