package com.example.registrationlogindemo.service;

import java.util.List;
import java.util.Optional;
import com.example.registrationlogindemo.dto.ConversationDto;
import com.example.registrationlogindemo.entity.Conversation;

public interface ConversationService {
    void saveConversation(ConversationDto conversationDto);
    Optional<Conversation> findById(Long id);
    List<ConversationDto> findConversationByUserid(Long userid);
}