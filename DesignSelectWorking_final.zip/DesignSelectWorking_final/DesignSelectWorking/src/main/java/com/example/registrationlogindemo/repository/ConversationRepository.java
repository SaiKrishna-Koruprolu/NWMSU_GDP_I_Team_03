package com.example.registrationlogindemo.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.registrationlogindemo.entity.Conversation;

public interface ConversationRepository extends JpaRepository<Conversation, Long> {
    @SuppressWarnings("null")
    Optional<Conversation> findById(Long id);
    List<Conversation> findConversationByUserid(Long userid);
}