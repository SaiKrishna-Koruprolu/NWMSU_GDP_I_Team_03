package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.entity.Email;
// Interface
public interface EmailService {
	// Method
	// To send a simple email
	boolean sendSimpleMail(Email details);
}

