package com.example.registrationlogindemo.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import com.example.registrationlogindemo.entity.Chat;

public interface ChatRepository extends JpaRepository<Chat, Long> {
    @SuppressWarnings("null")
    Optional<Chat> findById(Long id);
    List<Chat> findConversationBySenderid(Long senderid);
    List<Chat> findConversationByReceiverid(Long receiverid);
    List<Chat> findConversationByConversationid(int conversationid);
}