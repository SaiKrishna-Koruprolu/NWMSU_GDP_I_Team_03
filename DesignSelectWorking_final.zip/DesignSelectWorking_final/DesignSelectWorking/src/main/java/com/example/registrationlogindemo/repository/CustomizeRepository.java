package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.dto.CustomizeDto;
import com.example.registrationlogindemo.entity.Customize;

import java.util.List;
import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CustomizeRepository extends JpaRepository<Customize, Long> {
    @SuppressWarnings("null")
    Optional<Customize> findById(Long id);
    List<Customize> findProductsByUid(Long uid);
    List<Customize> findProductsByTitle(String title);
    List<Customize> findProductsByStatus(int status);
}
