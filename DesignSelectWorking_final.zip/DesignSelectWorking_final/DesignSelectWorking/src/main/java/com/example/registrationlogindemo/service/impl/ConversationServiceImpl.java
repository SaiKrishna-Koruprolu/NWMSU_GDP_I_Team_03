package com.example.registrationlogindemo.service.impl;

import org.springframework.stereotype.Service;

import com.example.registrationlogindemo.dto.ChatDto;
import com.example.registrationlogindemo.dto.ConversationDto;
import com.example.registrationlogindemo.entity.Chat;
import com.example.registrationlogindemo.entity.Conversation;
import com.example.registrationlogindemo.repository.ChatRepository;
import com.example.registrationlogindemo.repository.ConversationRepository;
import com.example.registrationlogindemo.service.ChatService;
import com.example.registrationlogindemo.service.ConversationService;

import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class ConversationServiceImpl implements ConversationService {
    private ConversationRepository conversationRepository;

    public ConversationServiceImpl(ConversationRepository conversationRepository) {
        this.conversationRepository = conversationRepository;
    }
    
    @Override
    public void saveConversation(ConversationDto chatDto) {
        Conversation chat = new Conversation();
        chat.setId(chatDto.getId());
        chat.setMsg(chatDto.getMsg());
        chat.setUserid(chatDto.getUserid());
        chat.setStatus(chatDto.getStatus());
        chat.setMsgdate(chatDto.getMsgdate());
        conversationRepository.save(chat);
    }

    @Override
    public Optional<Conversation> findById(Long id) {
        Optional<Conversation> chat = conversationRepository.findById(id);
        return chat;
    }

    private ConversationDto convertEntityToDto(Conversation chat){
        ConversationDto chatDto = new ConversationDto();
        chatDto.setId(chat.getId());
        chatDto.setMsg(chat.getMsg());
        chatDto.setUserid(chat.getUserid());
        chatDto.setStatus(chat.getStatus());
        chatDto.setMsgdate(chat.getMsgdate());
        return chatDto;
    }
    
    @Override
    public List<ConversationDto> findConversationByUserid(Long userid) {
        List<Conversation> chats = conversationRepository.findConversationByUserid(userid);
        return chats.stream().map((chat) -> convertEntityToDto(chat))
                .collect(Collectors.toList());
    }
    
}
