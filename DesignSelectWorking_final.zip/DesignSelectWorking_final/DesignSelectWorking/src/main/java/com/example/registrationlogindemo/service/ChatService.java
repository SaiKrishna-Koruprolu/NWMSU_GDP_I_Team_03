package com.example.registrationlogindemo.service;

import java.util.List;
import java.util.Optional;
import com.example.registrationlogindemo.dto.ChatDto;
import com.example.registrationlogindemo.entity.Chat;

public interface ChatService {
    void saveChat(ChatDto ChatDto);
    Optional<Chat> findById(Long id);
    List<ChatDto> findConversationBySenderid(Long senderid);
    List<ChatDto> findConversationByConversationid(int conversatioinid);
    List<ChatDto> findConversationByReceiverid(Long receiverid);
}