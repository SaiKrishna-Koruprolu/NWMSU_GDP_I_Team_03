package com.example.registrationlogindemo.controller;

import com.example.registrationlogindemo.dto.CartDto;
import com.example.registrationlogindemo.dto.ChatDto;
import com.example.registrationlogindemo.dto.ConversationDto;
import com.example.registrationlogindemo.dto.CustomizeDto;
import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.dto.UserDto;
import com.example.registrationlogindemo.entity.User;
import com.example.registrationlogindemo.service.UserService;
import com.example.registrationlogindemo.service.CartService;
import com.example.registrationlogindemo.service.ChatService;
import com.example.registrationlogindemo.service.ConversationService;
import com.example.registrationlogindemo.service.CustomizeService;
import com.example.registrationlogindemo.service.ProductService;

import jakarta.validation.Valid;

import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.multipart.MultipartFile;

import com.example.registrationlogindemo.entity.Cart;
import com.example.registrationlogindemo.entity.Chat;
import com.example.registrationlogindemo.entity.Conversation;
import com.example.registrationlogindemo.entity.Email;
import com.example.registrationlogindemo.entity.Product;

import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.Date;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.Optional;

@Controller
public class AuthController {
    private UserService userService;
    private ProductService productService;
    private CustomizeService customizeService;
    private CartService cartService;
    private ChatService chatService;
    private ConversationService conversationService;
    private String app_name = "Design Selection";
    
    public AuthController(UserService userService, 
                ProductService productService,
                CartService cartService,
                ChatService chatService,
                CustomizeService customizeService,
                ConversationService conversationService) {
        this.userService = userService;
        this.productService = productService;
        this.cartService = cartService;
        this.chatService = chatService;
        this.customizeService = customizeService;
        this.conversationService = conversationService;
    }

    @GetMapping("/")
    public String index(){
        return "login";
    }

    @GetMapping("/login")
    public String loginForm() {
        return "login";
    }

    @GetMapping("/forget-password")
    public String forget_pass(Email email) {
        return "forget_pass";
    }

    @GetMapping("/reset-password")
    public String showChangePasswordPage(Locale locale, Model model, 
    @RequestParam("token") String token) {
        User user = userService.getByResetPasswordToken(token);
        model.addAttribute("token", token);

        if (user == null) {
            model.addAttribute("message", "Invalid Token");
            return "redirect:/login?invalid_token";
        }
        return "reset_pass";
    }

    // handler method to handle user registration request
    @GetMapping("register")
    public String showRegistrationForm(Model model){
        UserDto user = new UserDto();
        model.addAttribute("user", user);
        return "register";
    }

    // handler method to handle register user form submit request
    @PostMapping("/register/save")
    public String registration(@Valid @ModelAttribute("user") UserDto user,
                               BindingResult result,
                               Model model){
        
        User existing = userService.findByEmail(user.getEmail());
        if (existing != null) {
            result.rejectValue("email", null, "There is already an account registered with that email");
        }
        if (result.hasErrors()) {
            model.addAttribute("user", user);
            return "register";
        }
        userService.saveUser(user);
        return "redirect:/login?success";
    }
    
    // @GetMapping("/users")
    // public String listRegisteredUsers(Model model){
    //     List<UserDto> users = userService.findAllUsers();
    //     model.addAttribute("users", users);
    //     return "users";
    // }
    
    @GetMapping("/home")
    public String getHome(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Home" );
            model.addAttribute("activeHome", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "home";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/new-arrivals")
    public String getNewarrival(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("new-arrival");
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "New-arrivals" );
            model.addAttribute("activeNewArrival", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);
            return "new-arrival";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/search")
    public String getNewarrivalSearch(@RequestParam String search, ModelMap model){
        List<ProductDto> products = productService.findProductsByName(search);
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Search" );
            model.addAttribute("activeNewArrival", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);
            return "new-arrival";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/collections/women")
    public String getWomenCollections(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("women");
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Women" );    
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("activeWomen", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "women";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/men")
    public String getMensCollection(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("men");

        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Men");    
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("activeMen", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "men";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/girls")
    public String getGirlsCollection(ModelMap model){  
        List<ProductDto> products = productService.findProductsByCategory("girls");

        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Girls" );  
            model.addAttribute("activeGirls", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "girls";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/boys")
    public String getBoysCollection(ModelMap model){
        User user = this.getUserById(model);
        List<ProductDto> products = productService.findProductsByCategory("boys");

        if(user.getId() != null){
            model.addAttribute("page_title", "Boys" );  
            model.addAttribute("activeBoys", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "boys";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/collections/kids")
    public String getKidsCollection(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("kids");

        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Kids" );  
            model.addAttribute("activeKids", "active");
            model.addAttribute("activeCollection", "active");    
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "kids";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/sale")
    public String getSale(ModelMap model){
        List<ProductDto> products = productService.findProductsByCategory("sale");

        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Sale" );  
            model.addAttribute("activeSale", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("products", products);

            return "sale";
        }else
            return "redirect:/login?error";
    }
    
    @SuppressWarnings("null")
    @GetMapping("/add-to-cart")
    public String getMethodName(@RequestParam Long productId, 
                            CartDto cart, ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            Optional<Product> product = productService.findById(productId);
            // add to cart table with user-id & product details
            if(product == null)
                return "redirect:/login?error";
            
            cart.setName(product.get().getName());
            cart.setCategory(product.get().getCategory());
            cart.setImage(product.get().getImage());
            cart.setPrice(product.get().getPrice());
            cart.setUid(user.getId());
            cart.setQty(1);
            
            cartService.saveCart(cart);
            return "redirect:/cart";
        }
        return "redirect:/login?error";
    }
    
    @GetMapping("/cart")
    public String getCart(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<CartDto> carts = cartService.findProductsByUid(user.getId());
            
            model.addAttribute("page_title", "Cart" );
            model.addAttribute("activeCart", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("carts", carts);
            return "cart";
        }else
            return "redirect:/login?error";
    }

    // @GetMapping("/chats")
    // public String getConversations(ModelMap model) {
    //     User user = this.getUserById(model);
    //     if(user.getId() != null){
    //         List<ConversationDto> chats = conversationService.findConversationByUserid(user.getId());
    //         model.addAttribute("page_title", "Chat");
    //         model.addAttribute("user_id", user.getId());
    //         model.addAttribute("role", user.getRole());
    //         model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
    //         model.addAttribute("conversations", chats);
    //         Chat chat = new Chat();
    //         model.addAttribute("chats", chat);
    //         return "chat";
    //     }else
    //         return "redirect:/login?error";
    // }

    @GetMapping("/chats")
    public String getConversations(ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<UserDto> vendors = userService.findByRole(3);
            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("conversations", vendors);
            model.addAttribute("conversationid", 0);

            Chat chat = new Chat();
            model.addAttribute("chats", chat);
            return "chat";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/vendor-chats")
    public String getVendorConversations(ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<UserDto> vendors = userService.findByRole(2);
            
            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("conversations", vendors);
            model.addAttribute("conversationid", 0);

            Chat chat = new Chat();
            model.addAttribute("chats", chat);
            return "chat";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/vendor-chat")
    public String getVendorChat(@RequestParam(required = true) int conversationid, ModelMap model) {
        User user = this.getUserById(model);

        if(user.getId() != null){
            List<ChatDto> chats = chatService.findConversationByConversationid((user.getId()).intValue());
            // List<ConversationDto> chat_conversations = conversationService.findConversationByUserid(user.getId());
            List<UserDto> chat_conversations = userService.findByRole(2);

            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("chats", chats);
            model.addAttribute("conversationid", conversationid);
            model.addAttribute("conversations", chat_conversations);
            return "chat";
        }else
            return "redirect:/login?error";
    }
   
    @GetMapping("/chat")
    public String getChat(@RequestParam(required = true) int conversationid, ModelMap model) {
        User user = this.getUserById(model);

        if(user.getId() != null){
            List<ChatDto> chats = chatService.findConversationByConversationid(conversationid);
            // List<ConversationDto> chat_conversations = conversationService.findConversationByUserid(user.getId());
            List<UserDto> chat_conversations = userService.findByRole(3);

            model.addAttribute("page_title", "Chat");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            model.addAttribute("chats", chats);
            model.addAttribute("conversationid", conversationid);
            model.addAttribute("conversations", chat_conversations);
            return "chat";
        }else
            return "redirect:/login?error";
    }
    
    @GetMapping("/chat-send")
    public String sendMsg(ChatDto chatDto,  ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            // add to cart table with user-id & product details
            // if(msg == null)
            //     return "redirect:/chat";
            DateTimeFormatter dtf = DateTimeFormatter.ofPattern("yyyy/MM/dd HH:mm:ss");
            LocalDateTime now = LocalDateTime.now();
            
            chatDto.setMsgdate(dtf.format(now));
            chatService.saveChat(chatDto);
            ConversationDto conversation = new ConversationDto();
            conversation.setMsg(chatDto.getMsg());
            conversation.setMsgdate(chatDto.getMsgdate());
            conversation.setUserid(chatDto.getSenderid());
            conversation.setStatus(0);
            try{
                conversationService.saveConversation(conversation);
            }catch(Exception ex){
                ex.printStackTrace();
            }
            if(user.getRole() == 2)
                return "redirect:/chat?conversationid="+chatDto.getConversationid();
            else if(user.getRole() == 3)
                return "redirect:/vendor-chat?conversationid="+chatDto.getConversationid();
        }
        return "redirect:/login?error";
    }
    
    @GetMapping("/customize")
    public String getCustomize(ModelMap model){
        // List<ProductDto> products = productService.findProductsByType("women");
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Customize" );
            model.addAttribute("activeCustomize", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            // model.addAttribute("products", products);

            return "customize";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/profile-details")
    public String profile_details(ModelMap model) {
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "User Profile");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("firstname", user.getFirstName());
            model.addAttribute("lastname", user.getLastName());
            model.addAttribute("email", user.getEmail());
            // UserDto userDto = new UserDto();
            // model.addAttribute("user", userDto);
            return "customer_profile";
        }else
            return "redirect:/login?error";
    }
    

    @PostMapping("/update-user-profile")
    public String update_user_profile(@Valid @ModelAttribute("user") UserDto userDto,  BindingResult result,  Model model){
            // User existing = this.getUserById(modelMap);
        User user = userService.findByEmail(userDto.getEmail());
        userService.updateUserDetails(user, userDto.getFirstName(), userDto.getLastName());
        return "redirect:/profile-details?success";
    }

    @GetMapping("/payment-page")
    public String paymentPage(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Payment" );
            model.addAttribute("activeHome", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
          
            return "payment";
        }else
            return "redirect:/login?error";
    }

    @PostMapping("/proceed-pay")
    public String proceed_pay(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Payment success" );
            model.addAttribute("activeHome", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "payment_success";
        }else
            return "redirect:/login?error";
    }

    @GetMapping("/bids/open-bids")
    public String openBids(ModelMap model){
        List<CustomizeDto> products = customizeService.findProductsByStatus(0);

        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Bids" );
            model.addAttribute("activeBids", "active");
            model.addAttribute("user_id", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", products);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            
            return "open_bids";
        }else
            return "redirect:/login?error";
    }

    public User getUserById(ModelMap model){
          // List<ProductDto> products = ProductService.findAllProducts();
          SecurityContext context=SecurityContextHolder.getContext();
          Authentication authentication=context.getAuthentication();
          User user = new User();
          try{
              String email=((UserDetails)authentication.getPrincipal()).getUsername();
              user = (User)userService.findByEmail(email);
          }catch(Exception ex){
          }
        return user;
    }

  
    @GetMapping("/products/my-products")
    public String my_products(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            List<ProductDto> products = productService.findProductsByUid(user.getId());
            
            model.addAttribute("page_title", "My Products" );
            model.addAttribute("activeProduct", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("products", products);
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            return "my_products";
        }else
            return "redirect:/login?error";
    }

   
    @GetMapping("/products/add-product")
    public String add_product(ModelMap model){
        User user = this.getUserById(model);
        if(user.getId() != null){
            model.addAttribute("page_title", "Product" );
            model.addAttribute("activeProduct", "active");
            model.addAttribute("uid", user.getId());
            model.addAttribute("role", user.getRole());
            model.addAttribute("uname", user.getFirstName()+" "+user.getLastName());
            
            return "add_product";
        }else
            return "redirect:/login?error";
    }

    public static String SYS_DIRECTORY = System.getProperty("user.dir");
    public static String UPLOAD_DIRECTORY = "/src/main/resources/static/img/product/";
    public static String FILE_DIRECTORY = "/img/product/";
    
    // handler method to handle register user form submit request
    @PostMapping("/products/add-product/save")
    public String saveProduct(@Valid @ModelAttribute("product") ProductDto product,
                            BindingResult result,
                            Model model,
                            @RequestParam("file_img") MultipartFile file)throws IOException{
                                
        StringBuilder fileNames = new StringBuilder();
        Path fileNameAndPath = Paths.get(SYS_DIRECTORY+UPLOAD_DIRECTORY, file.getOriginalFilename());
        fileNames.append(file.getOriginalFilename());
        
        try {
            Files.write(fileNameAndPath, file.getBytes());
        } catch (IOException e) {
            System.out.println("error file:--->"+e.getMessage());
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        
        product.setImage(FILE_DIRECTORY + file.getOriginalFilename());
        // model.addAttribute("msg", "Uploaded images: " + fileNames.toString());
        
        productService.saveProduct(product);
        return "redirect:/products/add-product?success";
    }


    @PostMapping("/products/upload-customize")
    public String uploadCustomize(@Valid @ModelAttribute("customize") CustomizeDto customizeDto,
                            BindingResult result,
                            Model model,
                            @RequestParam("file_img") MultipartFile file)throws IOException{
                                
        StringBuilder fileNames = new StringBuilder();
        Path fileNameAndPath = Paths.get(SYS_DIRECTORY+UPLOAD_DIRECTORY, file.getOriginalFilename());
        fileNames.append(file.getOriginalFilename());
        
        try {
            Files.write(fileNameAndPath, file.getBytes());
        } catch (IOException e) {
            System.out.println("error file:--->"+e.getMessage());
            // TODO Auto-generated catch block
            e.printStackTrace();
            return "redirect:/customize?error";
        }
        
        customizeDto.setImage(FILE_DIRECTORY + file.getOriginalFilename());
        // model.addAttribute("msg", "Uploaded images: " + fileNames.toString());
        
        customizeService.saveCustomize(customizeDto);
        return "redirect:/customize?success";
    }
}
