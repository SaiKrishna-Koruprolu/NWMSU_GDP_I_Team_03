package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.entity.Otp;
import org.springframework.data.jpa.repository.JpaRepository;

public interface OTPRepository extends JpaRepository<Otp, Long> {
    Otp findByEmail(String email);
}
