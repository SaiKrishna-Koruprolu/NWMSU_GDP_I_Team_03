package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.dto.UserDto;
import com.example.registrationlogindemo.entity.Product;
import java.util.List;

public interface ProductService {
    void saveUser(ProductDto productDto);
    
    Product findById(Long id);
    List<ProductDto> findAllProducts();
    List<ProductDto> findProductsByType(String type);
}
