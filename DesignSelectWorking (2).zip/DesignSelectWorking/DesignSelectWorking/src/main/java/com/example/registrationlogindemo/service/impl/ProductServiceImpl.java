package com.example.registrationlogindemo.service.impl;

import com.example.registrationlogindemo.dto.ProductDto;
import com.example.registrationlogindemo.entity.Product;
import com.example.registrationlogindemo.repository.ProductRepository;
import com.example.registrationlogindemo.service.ProductService;

import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class ProductServiceImpl implements ProductService {
    private ProductRepository productRepository;

    public ProductServiceImpl(ProductRepository productRepository) {
        this.productRepository = productRepository;
    }

    public void saveProduct(ProductDto productDto) {
        Product product = new Product();
        product.setName(productDto.getName());
        product.setPrice(productDto.getPrice());
        product.setRating(productDto.getRating());
        product.setId(productDto.getId());
        product.setType(productDto.getCategory());
        productRepository.save(product);
    }

    @Override
    public List<ProductDto> findAllProducts() {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public Product findById(Long id) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public List<ProductDto> findProductsByType(String type) {
        // TODO Auto-generated method stub
        return null;
    }

    @Override
    public void saveUser(ProductDto productDto) {
        // TODO Auto-generated method stub
    }
}
