package com.example.registrationlogindemo.repository;

import com.example.registrationlogindemo.entity.Product;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
    @SuppressWarnings("null")
    Optional<Product> findById(Long id);
    Product findProductsByType(String type);
}
