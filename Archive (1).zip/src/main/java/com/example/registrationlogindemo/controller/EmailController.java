package com.example.registrationlogindemo.controller;

import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import com.example.registrationlogindemo.service.EmailService;
import com.example.registrationlogindemo.service.OtpService;
import com.example.registrationlogindemo.repository.OTPRepository;
import com.example.registrationlogindemo.repository.UserRepository;
import com.example.registrationlogindemo.dto.OtpDto;
import com.example.registrationlogindemo.entity.*;
// Annotation
@Controller
// Class
public class EmailController {
	@Autowired private EmailService emailService;
    private UserRepository userRepository;
    private OtpService otpService;

    public EmailController(UserRepository userRepository, OtpService otpService) {
        this.userRepository = userRepository;
        this.otpService = otpService;
    }
	// Sending a simple Email
	@PostMapping("/forget-password/proceed")
	public String resetPassword(@RequestParam("email") String email){
			User user = userRepository.findByEmail(email);
			if(user != null){
				Email details = new Email();
				Random rand = new Random();
				String otp = rand.nextInt(10000)+"";
				details.setMsgBody("Your OTP is : "+otp);
				details.setRecipient(email);
				details.setSubject("Reset your account password? - Design Select");
				Boolean status = emailService.sendSimpleMail(details);
				if(status){
					OtpDto otp_model = new OtpDto();
					otp_model.setEmail(email);
					otp_model.setOtp(otp);
					otpService.saveOtp(otp_model);
					return "redirect:/forget_password?otp"; //otp_check
				}
				else 
					return "redirect:/forget_password?failed";
			}
			else	return "redirect:/forget-password?failed";
		}

	@PostMapping("/check-otp")
	public String checkOtp(@RequestParam("email") String email){
			User user = userRepository.findByEmail(email);
			if(user != null){
				Email details = new Email();
				String otp = "4455";
				details.setMsgBody("Your OTP is : "+otp);
				details.setRecipient(email);
				details.setSubject("Reset your account password? - Design Select");
				Boolean status = emailService.sendSimpleMail(details);
				if(status)
					return "redirect:/forget_password?otp"; //otp_check
				else 
					return "redirect:/forget_password?failed";
			}
			else	return "redirect:/forget-password?failed";
		}
	}
