package com.example.registrationlogindemo.service;

import com.example.registrationlogindemo.dto.OtpDto;
import com.example.registrationlogindemo.entity.Otp;

public interface OtpService {
    void saveOtp(OtpDto otpdDto);
    Otp findByEmail(String email);
}
